package com.vazbass.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioPlaybackCaptureConfiguration
import android.media.AudioRecord
import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.media.audiofx.LoudnessEnhancer
import android.media.audiofx.Visualizer
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sqrt

/**
 * Работает в фоне: слушает звук любого плеера и (по желанию) включает системные
 * аудиоэффекты — «саб в багажнике».
 */
class AudioService : Service() {

    companion object {
        const val ACTION_STOP = "com.vazbass.app.STOP"
        private const val CHANNEL = "vazbass"
        private const val NOTIF_ID = 77
    }

    private lateinit var prefs: SharedPreferences
    private val analyzer = Analyzer()

    private var visualizer: Visualizer? = null
    private var projection: MediaProjection? = null
    private var recorder: AudioRecord? = null
    private var captureThread: Thread? = null
    @Volatile private var capturing = false

    private var bassBoost: BassBoost? = null
    private var equalizer: Equalizer? = null
    private var loudness: LoudnessEnhancer? = null

    private val prefListener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        if (key == Prefs.SUB_ON || key == Prefs.POWER || key == Prefs.MUFFLE) applyEffects()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        prefs = Prefs.get(this)
        prefs.registerOnSharedPreferenceChangeListener(prefListener)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        val mode = intent?.getIntExtra("mode", 0) ?: 0
        val useProjection = mode == 1 && Build.VERSION.SDK_INT >= 29

        createChannel()
        val notification = buildNotification()
        if (Build.VERSION.SDK_INT >= 29) {
            val type = if (useProjection) {
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            } else {
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK
            }
            startForeground(NOTIF_ID, notification, type)
        } else {
            startForeground(NOTIF_ID, notification)
        }

        releaseCapture()
        AudioBus.error = null
        AudioBus.lastSignal = System.currentTimeMillis()
        AudioBus.running = true

        if (useProjection) {
            val code = intent?.getIntExtra("code", 0) ?: 0
            val data = intent?.getParcelableExtra<Intent>("data")
            if (data == null) {
                AudioBus.error = "Нет разрешения на запись звука. Нажми «Старт» ещё раз."
            } else {
                startPlaybackCapture(code, data)
            }
        } else {
            startVisualizer()
        }
        applyEffects()
        return START_NOT_STICKY
    }

    // ---------- Захват звука: способ 1 — системный микшер ----------

    private fun startVisualizer() {
        try {
            val v = Visualizer(0)
            v.setEnabled(false)
            val range = Visualizer.getCaptureSizeRange()
            v.setCaptureSize(range[1])
            v.setDataCaptureListener(object : Visualizer.OnDataCaptureListener {
                override fun onWaveFormDataCapture(vis: Visualizer?, waveform: ByteArray?, samplingRate: Int) {}
                override fun onFftDataCapture(vis: Visualizer?, fft: ByteArray?, samplingRate: Int) {
                    if (fft != null) handleFft(fft, samplingRate)
                }
            }, Visualizer.getMaxCaptureRate(), false, true)
            v.setEnabled(true)
            visualizer = v
        } catch (e: Exception) {
            AudioBus.error = "Этот телефон не отдаёт системный звук. Выбери метод «Запись воспроизведения» ниже."
        }
    }

    private fun handleFft(fft: ByteArray, samplingRate: Int) {
        val n = fft.size
        val bins = n / 2
        val mags = FloatArray(bins)
        mags[0] = Math.abs(fft[0].toInt()) / 128f
        for (k in 1 until bins) {
            val re = fft[2 * k].toInt()
            val im = fft[2 * k + 1].toInt()
            mags[k] = sqrt((re * re + im * im).toFloat()) / 128f
        }
        val binHz = (samplingRate / 1000f) / n
        analyzer.push(mags, binHz)
    }

    // ---------- Захват звука: способ 2 — запись воспроизведения (Android 10+) ----------

    private fun startPlaybackCapture(code: Int, data: Intent) {
        try {
            val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            val p = mpm.getMediaProjection(code, data)
            projection = p
            p.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() {
                    stopSelf()
                }
            }, Handler(Looper.getMainLooper()))

            val cfg = AudioPlaybackCaptureConfiguration.Builder(p)
                .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
                .addMatchingUsage(AudioAttributes.USAGE_GAME)
                .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
                .build()
            val fmt = AudioFormat.Builder()
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setSampleRate(44100)
                .setChannelMask(AudioFormat.CHANNEL_IN_STEREO)
                .build()
            val minBuf = AudioRecord.getMinBufferSize(
                44100, AudioFormat.CHANNEL_IN_STEREO, AudioFormat.ENCODING_PCM_16BIT
            )
            val rec = AudioRecord.Builder()
                .setAudioPlaybackCaptureConfig(cfg)
                .setAudioFormat(fmt)
                .setBufferSizeInBytes(maxOf(minBuf, 16384))
                .build()
            rec.startRecording()
            recorder = rec
            capturing = true

            captureThread = Thread {
                val n = 2048
                val hop = 1024
                val window = FloatArray(n)
                val hann = FloatArray(n) { (0.5 - 0.5 * cos(2.0 * PI * it / (n - 1))).toFloat() }
                val buf = ShortArray(hop * 2)
                val re = FloatArray(n)
                val im = FloatArray(n)
                val mags = FloatArray(n / 2)
                while (capturing) {
                    val read = rec.read(buf, 0, buf.size)
                    if (read < 0) break
                    if (read == 0) continue
                    val frames = read / 2
                    System.arraycopy(window, frames, window, 0, n - frames)
                    for (i in 0 until frames) {
                        window[n - frames + i] = (buf[2 * i] + buf[2 * i + 1]) / 65536f
                    }
                    for (i in 0 until n) {
                        re[i] = window[i] * hann[i]
                        im[i] = 0f
                    }
                    Fft.transform(re, im)
                    for (k in 0 until n / 2) {
                        mags[k] = sqrt(re[k] * re[k] + im[k] * im[k]) * 4f / n
                    }
                    analyzer.push(mags, 44100f / n)
                }
            }.also {
                it.isDaemon = true
                it.start()
            }
        } catch (e: Exception) {
            AudioBus.error = "Не удалось начать запись воспроизведения: ${e.message}"
        }
    }

    // ---------- «Саб в багажнике»: системные аудиоэффекты ----------

    private fun applyEffects() {
        if (!prefs.getBoolean(Prefs.SUB_ON, false)) {
            releaseEffects()
            return
        }
        val power = prefs.getInt(Prefs.POWER, 80) / 100f
        val muffle = prefs.getInt(Prefs.MUFFLE, 60) / 100f

        try {
            val bb = bassBoost ?: BassBoost(100, 0).also { bassBoost = it }
            if (bb.getStrengthSupported()) bb.setStrength((power * 1000f).toInt().toShort())
            bb.setEnabled(true)
        } catch (e: Exception) {
            bassBoost = null
        }

        try {
            val eq = equalizer ?: Equalizer(100, 0).also { equalizer = it }
            val range = eq.getBandLevelRange()
            val lo = range[0].toInt()
            val hi = range[1].toInt()
            for (b in 0 until eq.getNumberOfBands()) {
                val f = eq.getCenterFreq(b.toShort()) / 1000
                val level: Float = when {
                    f < 150 -> hi * power
                    f < 500 -> hi * 0.6f * power
                    f < 2000 -> lo * 0.5f * muffle
                    else -> lo * muffle
                }
                eq.setBandLevel(b.toShort(), level.toInt().coerceIn(lo, hi).toShort())
            }
            eq.setEnabled(true)
        } catch (e: Exception) {
            equalizer = null
        }

        try {
            val le = loudness ?: LoudnessEnhancer(0).also { loudness = it }
            le.setTargetGain((power * 400f).toInt())
            le.setEnabled(true)
        } catch (e: Exception) {
            loudness = null
        }
    }

    private fun releaseEffects() {
        try { bassBoost?.release() } catch (e: Exception) {}
        try { equalizer?.release() } catch (e: Exception) {}
        try { loudness?.release() } catch (e: Exception) {}
        bassBoost = null
        equalizer = null
        loudness = null
    }

    // ---------- Служебное ----------

    private fun releaseCapture() {
        capturing = false
        try { visualizer?.setEnabled(false) } catch (e: Exception) {}
        try { visualizer?.release() } catch (e: Exception) {}
        visualizer = null
        try { recorder?.stop() } catch (e: Exception) {}
        try { captureThread?.join(400) } catch (e: Exception) {}
        try { recorder?.release() } catch (e: Exception) {}
        recorder = null
        captureThread = null
        try { projection?.stop() } catch (e: Exception) {}
        projection = null
    }

    private fun createChannel() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "VAZ Bass", NotificationManager.IMPORTANCE_LOW)
        )
    }

    private fun buildNotification(): Notification {
        val stop = PendingIntent.getService(
            this, 0,
            Intent(this, AudioService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val open = PendingIntent.getActivity(
            this, 1, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle("VAZ Bass")
            .setContentText("Слушаю музыку из любого плеера")
            .setContentIntent(open)
            .addAction(Notification.Action.Builder(0, "Стоп", stop).build())
            .setOngoing(true)
            .build()
    }

    override fun onDestroy() {
        prefs.unregisterOnSharedPreferenceChangeListener(prefListener)
        releaseCapture()
        releaseEffects()
        AudioBus.running = false
        AudioBus.reset()
        stopForeground(true)
        super.onDestroy()
    }
}
