package com.vazbass.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.SweepGradient
import android.graphics.Typeface
import android.view.View
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.min
import kotlin.math.sin

/**
 * ВАЗ-2110 сзади с открытым багажником и огромным сабом.
 * Рисуется в виртуальных координатах 1000 x 760 и масштабируется под экран.
 */
class CarView(context: Context) : View(context) {

    var carBlack: Boolean = true
        set(v) { field = v; dirty = true }
    var accent: Int = 0xFF00B0FF.toInt()
        set(v) { field = v; dirty = true }
    var sensitivity: Float = 1f
    var showBars: Boolean = true

    private var dirty = true

    private val VW = 1000f
    private val VH = 760f
    private val BANDS = AudioBus.BAND_COUNT

    // сцена
    private val SX = 500f      // центр саба
    private val SY = 411f
    private val SR = 124f      // радиус саба

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val textP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private val dash = DashPathEffect(floatArrayOf(8f, 6f), 0f)

    private val cabinPath = Path()
    private val glassPath = Path()
    private val streak1 = Path()
    private val streak2 = Path()
    private val lidOuter = Path()
    private val lidInner = Path()
    private val bodyPath = Path()
    private val lampPath = Path()

    private val rcos = FloatArray(36) { cos(it * 2.0 * PI / 36.0).toFloat() }
    private val rsin = FloatArray(36) { sin(it * 2.0 * PI / 36.0).toFloat() }
    private val ledX = floatArrayOf(326f, 674f)

    // шейдеры
    private lateinit var bgShader: Shader
    private lateinit var bodyShader: Shader
    private lateinit var sheenShader: Shader
    private lateinit var bumperSheen: Shader
    private lateinit var glassShader: Shader
    private lateinit var lidInnerShader: Shader
    private lateinit var carpetShader: Shader
    private lateinit var tireShader: Shader
    private lateinit var floorShader: Shader
    private lateinit var floorGlowShader: Shader
    private lateinit var barShader: Shader
    private lateinit var lampGlowShader: Shader
    private lateinit var subGlowShader: Shader
    private lateinit var flangeShader: Shader
    private lateinit var surroundShader: Shader
    private lateinit var coneShader: Shader
    private lateinit var capShader: Shader
    private lateinit var chromeShader: Shader
    private var edgeColor = 0
    private var creaseColor = 0

    // состояние анимации
    private var lastNs = 0L
    private var time = 0f
    private var pos = 0f          // ход диффузора
    private var vel = 0f
    private var light = 0f        // яркость подсветки
    private var prevTarget = 0f
    private var waveCd = 0f
    private val waves = FloatArray(6) { -1f }
    private val bars = FloatArray(AudioBus.BAND_COUNT)
    private val rawBands = FloatArray(AudioBus.BAND_COUNT)
    private var bounce = 0f
    private var shakeX = 0f
    private var tilt = 0f

    init {
        buildGeometry()
        textP.typeface = Typeface.create("sans-serif-condensed", Typeface.BOLD)
        textP.textAlign = Paint.Align.CENTER
        textP.color = 0xFF111111.toInt()
    }

    private fun buildGeometry() {
        cabinPath.apply {
            moveTo(215f, 262f)
            cubicTo(235f, 170f, 290f, 80f, 345f, 40f)
            quadTo(500f, 22f, 655f, 40f)
            cubicTo(710f, 80f, 765f, 170f, 785f, 262f)
            close()
        }
        glassPath.apply {
            moveTo(248f, 252f)
            cubicTo(264f, 172f, 308f, 92f, 358f, 58f)
            quadTo(500f, 42f, 642f, 58f)
            cubicTo(692f, 92f, 736f, 172f, 752f, 252f)
            close()
        }
        streak1.apply {
            moveTo(330f, 260f); lineTo(374f, 260f); lineTo(444f, 40f); lineTo(400f, 40f); close()
        }
        streak2.apply {
            moveTo(402f, 260f); lineTo(418f, 260f); lineTo(470f, 40f); lineTo(454f, 40f); close()
        }
        lidOuter.apply {
            moveTo(232f, 264f)
            lineTo(768f, 264f)
            cubicTo(752f, 200f, 722f, 140f, 700f, 100f)
            quadTo(500f, 86f, 300f, 100f)
            cubicTo(278f, 140f, 248f, 200f, 232f, 264f)
            close()
        }
        lidInner.apply {
            moveTo(256f, 252f)
            lineTo(744f, 252f)
            cubicTo(730f, 196f, 704f, 146f, 686f, 114f)
            quadTo(500f, 100f, 314f, 114f)
            cubicTo(296f, 146f, 270f, 196f, 256f, 252f)
            close()
        }
        bodyPath.apply {
            moveTo(150f, 262f)
            lineTo(850f, 262f)
            quadTo(884f, 268f, 886f, 318f)
            lineTo(888f, 544f)
            lineTo(112f, 544f)
            lineTo(114f, 318f)
            quadTo(116f, 268f, 150f, 262f)
            close()
        }
        lampPath.apply {
            moveTo(134f, 300f)
            lineTo(276f, 296f)
            lineTo(276f, 438f)
            lineTo(156f, 442f)
            quadTo(134f, 430f, 132f, 380f)
            close()
        }
    }

    private fun withAlpha(c: Int, a: Int): Int = (a.coerceIn(0, 255) shl 24) or (c and 0x00FFFFFF)

    private fun lerp(c1: Int, c2: Int, t: Float): Int {
        val k = t.coerceIn(0f, 1f)
        val a = (Color.alpha(c1) + (Color.alpha(c2) - Color.alpha(c1)) * k).toInt()
        val r = (Color.red(c1) + (Color.red(c2) - Color.red(c1)) * k).toInt()
        val g = (Color.green(c1) + (Color.green(c2) - Color.green(c1)) * k).toInt()
        val b = (Color.blue(c1) + (Color.blue(c2) - Color.blue(c1)) * k).toInt()
        return Color.argb(a, r, g, b)
    }

    private fun fillP(color: Int = Color.WHITE, sh: Shader? = null): Paint {
        p.reset()
        p.isAntiAlias = true
        p.style = Paint.Style.FILL
        p.color = color
        p.shader = sh
        return p
    }

    private fun strokeP(color: Int, w: Float, sh: Shader? = null): Paint {
        p.reset()
        p.isAntiAlias = true
        p.style = Paint.Style.STROKE
        p.strokeWidth = w
        p.color = color
        p.shader = sh
        return p
    }

    private fun buildShaders() {
        val black = carBlack
        val tm = Shader.TileMode.CLAMP
        val bodyCols = if (black) {
            intArrayOf(0xFF08080A.toInt(), 0xFF191A1F.toInt(), 0xFF2A2B32.toInt(), 0xFF191A1F.toInt(), 0xFF08080A.toInt())
        } else {
            intArrayOf(0xFFA9ADB5.toInt(), 0xFFE2E4E8.toInt(), 0xFFFAFAF8.toInt(), 0xFFE2E4E8.toInt(), 0xFFA9ADB5.toInt())
        }
        bodyShader = LinearGradient(110f, 0f, 890f, 0f, bodyCols, floatArrayOf(0f, 0.25f, 0.5f, 0.75f, 1f), tm)
        val sheenCols = if (black) {
            intArrayOf(0x30FFFFFF, 0x00FFFFFF, 0x66000000)
        } else {
            intArrayOf(0x40FFFFFF, 0x00FFFFFF, 0x40000000)
        }
        sheenShader = LinearGradient(0f, 262f, 0f, 548f, sheenCols, floatArrayOf(0f, 0.45f, 1f), tm)
        bumperSheen = LinearGradient(0f, 540f, 0f, 654f, sheenCols, floatArrayOf(0f, 0.45f, 1f), tm)
        edgeColor = if (black) 0xFF000000.toInt() else 0xFF7C8089.toInt()
        creaseColor = if (black) 0x33FFFFFF else 0x33000000

        glassShader = LinearGradient(0f, 40f, 0f, 255f, 0xFF22364A.toInt(), 0xFF05080C.toInt(), tm)
        lidInnerShader = LinearGradient(0f, 100f, 0f, 260f, 0xFF2D2F36.toInt(), 0xFF141519.toInt(), tm)
        carpetShader = LinearGradient(0f, 282f, 0f, 540f, 0xFF1A1B1F.toInt(), 0xFF0A0A0C.toInt(), tm)
        tireShader = LinearGradient(0f, 606f, 0f, 726f, 0xFF212227.toInt(), 0xFF050506.toInt(), tm)
        floorShader = LinearGradient(0f, 700f, 0f, 1100f, 0xFF171A23.toInt(), 0xFF05060A.toInt(), tm)
        chromeShader = LinearGradient(0f, 640f, 0f, 664f, 0xFFE9ECF2.toInt(), 0xFF666A73.toInt(), tm)

        val ac = accent
        floorGlowShader = RadialGradient(500f, 715f, 430f, withAlpha(ac, 255), withAlpha(ac, 0), tm)
        barShader = LinearGradient(0f, 700f, 0f, 60f, withAlpha(ac, 150), withAlpha(ac, 0), tm)
        subGlowShader = RadialGradient(SX, SY, 200f, withAlpha(ac, 255), withAlpha(ac, 0), tm)
        lampGlowShader = RadialGradient(204f, 368f, 160f, 0xFFFF2020.toInt(), 0x00FF2020, tm)

        val fc = intArrayOf(
            0xFF3A3C43.toInt(), 0xFF9AA0AA.toInt(), 0xFF3A3C43.toInt(), 0xFF1A1B1F.toInt(),
            0xFF3A3C43.toInt(), 0xFF9AA0AA.toInt(), 0xFF3A3C43.toInt(), 0xFF1A1B1F.toInt(), 0xFF3A3C43.toInt()
        )
        val fp = FloatArray(9) { it / 8f }
        flangeShader = SweepGradient(SX, SY, fc, fp)

        surroundShader = RadialGradient(
            SX, SY, SR * 0.89f,
            intArrayOf(0xFF000000.toInt(), 0xFF000000.toInt(), 0xFF1C1D22.toInt(), 0xFF2B2C33.toInt(), 0xFF0E0F11.toInt(), 0xFF000000.toInt()),
            floatArrayOf(0f, 0.81f, 0.85f, 0.92f, 0.97f, 1f), tm
        )
        coneShader = RadialGradient(
            SX, SY, SR * 0.72f,
            intArrayOf(0xFF34363D.toInt(), 0xFF23242A.toInt(), 0xFF15161A.toInt(), 0xFF0B0B0D.toInt()),
            floatArrayOf(0f, 0.35f, 0.75f, 1f), tm
        )
        capShader = RadialGradient(
            SX - SR * 0.08f, SY - SR * 0.1f, SR * 0.3f,
            intArrayOf(0xFFB4B9C4.toInt(), 0xFF5A5E68.toInt(), 0xFF1A1B1F.toInt()),
            floatArrayOf(0f, 0.55f, 1f), tm
        )
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        bgShader = LinearGradient(
            0f, 0f, 0f, h.toFloat(), 0xFF04050A.toInt(), 0xFF111522.toInt(), Shader.TileMode.CLAMP
        )
    }

    // ---------- анимация ----------

    private fun step(dt: Float) {
        val rawBass: Float
        if (AudioBus.running) {
            rawBass = AudioBus.bass
            System.arraycopy(AudioBus.bands, 0, rawBands, 0, BANDS)
        } else {
            // демо-режим: ровный бит 128 BPM
            val ph = (time * 2.1333f) % 1f
            val kick = exp(-ph * 5.5f)
            rawBass = 0.8f * kick
            for (i in 0 until BANDS) {
                rawBands[i] = (0.5f * kick * (1f - i / 36f) + 0.22f * abs(sin(time * 1.6f + i * 0.65f))).coerceIn(0f, 1f)
            }
        }
        val target = (rawBass * sensitivity).coerceIn(0f, 1.25f)

        val h = dt / 2f
        for (s in 0 until 2) {
            val acc = 720f * (target - pos) - 30f * vel
            vel += acc * h
            pos += vel * h
        }
        if (pos < -0.25f) { pos = -0.25f; vel = 0f }

        light = if (target > light) min(target, 1f) else (light - dt * 3.2f).coerceAtLeast(0f)

        waveCd -= dt
        if (target - prevTarget > 0.2f && target > 0.45f && waveCd <= 0f) {
            for (i in waves.indices) {
                if (waves[i] < 0f) { waves[i] = 0f; break }
            }
            waveCd = 0.2f
        }
        prevTarget = target
        for (i in waves.indices) {
            if (waves[i] >= 0f) {
                waves[i] += dt * 1.5f
                if (waves[i] > 1f) waves[i] = -1f
            }
        }

        for (i in 0 until BANDS) {
            val t = (rawBands[i] * sensitivity).coerceIn(0f, 1f)
            val rate = if (t > bars[i]) 28f else 6f
            bars[i] += (t - bars[i]) * (1f - exp(-rate * dt))
        }

        val e = pos.coerceIn(0f, 1.3f)
        bounce = e * 5.5f
        shakeX = sin(time * 83f) * e * 1.3f
        tilt = sin(time * 53f) * e * 0.12f
    }

    // ---------- рисование ----------

    override fun onDraw(c: Canvas) {
        if (dirty) {
            buildShaders()
            dirty = false
        }
        val now = System.nanoTime()
        var dt = (now - lastNs) / 1e9f
        lastNs = now
        if (dt > 0.033f) dt = 0.033f
        if (dt < 0.001f) dt = 0.001f
        time += dt
        step(dt)

        c.drawRect(0f, 0f, width.toFloat(), height.toFloat(), fillP(Color.WHITE, bgShader))
        val s = min(width / VW, height / VH)
        c.save()
        c.translate((width - VW * s) / 2f, (height - VH * s) / 2f)
        c.scale(s, s)
        drawScene(c)
        c.restore()
        postInvalidateOnAnimation()
    }

    private fun drawScene(c: Canvas) {
        val lt = light.coerceIn(0f, 1f)

        // эквалайзер на фоне
        if (showBars) {
            val bw = 880f / BANDS
            for (i in 0 until BANDS) {
                val hh = 40f + bars[i] * 600f
                val l = 60f + i * bw + 3f
                rect.set(l, 700f - hh, l + bw - 6f, 700f)
                c.drawRoundRect(rect, 5f, 5f, fillP(Color.WHITE, barShader))
            }
        }

        // пол
        c.drawRect(-600f, 700f, 1600f, 2000f, fillP(Color.WHITE, floorShader))
        c.drawRect(-600f, 699f, 1600f, 701.5f, fillP(withAlpha(accent, 70 + (lt * 120f).toInt())))
        c.save()
        c.scale(1f, 0.22f, 500f, 715f)
        c.drawCircle(500f, 715f, 430f, fillP(Color.argb((40 + 200 * lt).toInt().coerceIn(0, 255), 255, 255, 255), floorGlowShader))
        c.restore()
        c.drawOval(100f, 672f, 900f, 748f, fillP(0xB0000000.toInt()))

        // колёса (стоят на земле, кузов качается над ними)
        drawTire(c, 168f)
        drawTire(c, 730f)

        c.save()
        c.translate(shakeX, bounce)
        c.rotate(tilt, 500f, 700f)
        drawCar(c, lt)
        c.restore()
    }

    private fun drawTire(c: Canvas, x: Float) {
        rect.set(x, 606f, x + 102f, 726f)
        c.drawRoundRect(rect, 18f, 18f, fillP(Color.WHITE, tireShader))
        c.drawRoundRect(rect, 18f, 18f, strokeP(0xFF2C2E34.toInt(), 3f))
        val tp = strokeP(0xFF0C0D0F.toInt(), 3f)
        for (i in 0..4) {
            val yy = 660f + i * 13f
            c.drawLine(x + 10f, yy, x + 92f, yy, tp)
        }
    }

    private fun drawCar(c: Canvas, lt: Float) {
        // крыша и стойки
        c.drawPath(cabinPath, fillP(Color.WHITE, bodyShader))
        c.drawPath(cabinPath, strokeP(edgeColor, 3f))

        // заднее стекло
        c.drawPath(glassPath, fillP(Color.WHITE, glassShader))
        c.save()
        c.clipPath(glassPath)
        c.drawPath(streak1, fillP(0x18FFFFFF))
        c.drawPath(streak2, fillP(0x10FFFFFF))
        c.restore()
        c.drawPath(glassPath, strokeP(0xFF050607.toInt(), 5f))

        // открытая крышка багажника (изнутри)
        c.drawPath(lidOuter, fillP(Color.WHITE, bodyShader))
        c.drawPath(lidOuter, strokeP(edgeColor, 3f))
        c.drawPath(lidInner, fillP(Color.WHITE, lidInnerShader))
        c.drawPath(lidInner, strokeP(0xFF050506.toInt(), 4f))
        val rp = strokeP(0xFF3A3C44.toInt(), 7f)
        rp.strokeCap = Paint.Cap.ROUND
        c.drawLine(338f, 148f, 662f, 148f, rp)
        c.drawLine(318f, 184f, 682f, 184f, rp)
        c.drawLine(298f, 220f, 702f, 220f, rp)
        c.drawLine(500f, 124f, 500f, 238f, rp)

        // задняя панель кузова
        c.drawPath(bodyPath, fillP(Color.WHITE, bodyShader))
        c.drawPath(bodyPath, fillP(Color.WHITE, sheenShader))
        c.drawPath(bodyPath, strokeP(edgeColor, 3f))
        c.drawLine(126f, 296f, 874f, 296f, strokeP(creaseColor, 2.5f))

        // проём багажника
        rect.set(290f, 272f, 710f, 548f)
        c.drawRoundRect(rect, 26f, 26f, fillP(0xFF030304.toInt()))
        rect.set(300f, 282f, 700f, 540f)
        c.drawRoundRect(rect, 14f, 14f, fillP(Color.WHITE, carpetShader))
        rect.set(310f, 292f, 690f, 530f)
        val st = strokeP(0xFF30323A.toInt(), 1.6f)
        st.pathEffect = dash
        c.drawRoundRect(rect, 10f, 10f, st)

        // свечение внутри
        c.save()
        c.clipRect(300f, 282f, 700f, 540f)
        c.drawCircle(SX, SY, 200f, fillP(Color.argb((25 + 95 * lt).toInt().coerceIn(0, 255), 255, 255, 255), subGlowShader))
        c.restore()

        // светодиодные полосы по бокам
        val la = (90 + 165 * lt).toInt()
        for (x in ledX) {
            val g = strokeP(withAlpha(accent, la / 4), 16f)
            g.strokeCap = Paint.Cap.ROUND
            c.drawLine(x, 300f, x, 522f, g)
            val core = strokeP(withAlpha(accent, la), 5f)
            core.strokeCap = Paint.Cap.ROUND
            c.drawLine(x, 300f, x, 522f, core)
        }

        // САБ
        drawSub(c, lt)

        // фонари
        drawLamps(c, lt)

        // бампер, номер, выхлоп
        drawBumper(c)

        // ударные волны от баса
        for (i in waves.indices) {
            val a = waves[i]
            if (a >= 0f) {
                val rad = 140f + a * 340f
                c.drawCircle(SX, SY, rad, strokeP(withAlpha(accent, ((1f - a) * 90f).toInt()), 3f + 7f * (1f - a)))
            }
        }
    }

    private fun drawSub(c: Canvas, lt: Float) {
        val cx = SX
        val cy = SY
        val r = SR
        val e = pos.coerceIn(-0.3f, 1.3f)

        // колодец
        c.drawCircle(cx, cy, r + 3f, fillP(0xFF000000.toInt()))

        // фланец с болтами
        c.drawCircle(cx, cy, r * 0.94f, strokeP(Color.WHITE, r * 0.12f, flangeShader))
        for (i in 0 until 8) {
            val a = i * (PI / 4.0) + PI / 8.0
            val bx = cx + cos(a).toFloat() * r * 0.94f
            val by = cy + sin(a).toFloat() * r * 0.94f
            c.drawCircle(bx, by, 5f, fillP(0xFF15161A.toInt()))
            c.drawCircle(bx - 0.8f, by - 0.8f, 3.2f, fillP(0xFFAEB3BD.toInt()))
        }

        // подвес (резина)
        c.drawCircle(cx, cy, r * 0.89f, fillP(Color.WHITE, surroundShader))

        // диффузор: при ходе «вперёд» чуть растёт
        val cs = 1f + 0.05f * e
        c.save()
        c.scale(cs, cs, cx, cy)
        c.drawCircle(cx, cy, r * 0.72f, fillP(Color.WHITE, coneShader))

        val ribP = strokeP(0x14FFFFFF, 1.4f)
        var rr = r * 0.30f
        while (rr < r * 0.71f) {
            c.drawCircle(cx, cy, rr, ribP)
            rr += r * 0.07f
        }
        val rp2 = strokeP(0x0DFFFFFF, 1.2f)
        for (i in 0 until 36) {
            c.drawLine(
                cx + rcos[i] * r * 0.27f, cy + rsin[i] * r * 0.27f,
                cx + rcos[i] * r * 0.72f, cy + rsin[i] * r * 0.72f, rp2
            )
        }

        rect.set(cx - r * 0.52f, cy - r * 0.52f, cx + r * 0.52f, cy + r * 0.52f)
        val hl = strokeP(Color.argb((35 + 90 * e.coerceIn(0f, 1f)).toInt(), 255, 255, 255), 7f)
        hl.strokeCap = Paint.Cap.ROUND
        c.drawArc(rect, 200f, 55f, false, hl)
        val hl2 = strokeP(withAlpha(accent, (20 + 80 * lt).toInt()), 5f)
        hl2.strokeCap = Paint.Cap.ROUND
        c.drawArc(rect, 30f, 45f, false, hl2)
        c.restore()

        // пылезащитный колпак — ходит сильнее
        val ds = 1f + 0.12f * e
        c.save()
        c.scale(ds, ds, cx, cy)
        c.drawCircle(cx, cy, r * 0.27f, strokeP(0x99000000.toInt(), 5f))
        c.drawCircle(cx, cy, r * 0.25f, fillP(Color.WHITE, capShader))
        c.drawCircle(cx, cy, r * 0.25f, strokeP(0xFF08080A.toInt(), 2.5f))
        rect.set(cx - r * 0.15f, cy - r * 0.17f, cx - r * 0.03f, cy - r * 0.07f)
        c.drawOval(rect, fillP(0x66FFFFFF))
        c.restore()

        // неоновое кольцо
        val ra = r + 8f
        c.drawCircle(cx, cy, ra, strokeP(withAlpha(accent, (22 * lt).toInt()), 30f))
        c.drawCircle(cx, cy, ra, strokeP(withAlpha(accent, (20 + 55 * lt).toInt()), 16f))
        c.drawCircle(cx, cy, ra, strokeP(withAlpha(accent, (120 + 135 * lt).toInt()), 5f))
    }

    private fun drawLamps(c: Canvas, lt: Float) {
        for (side in 0..1) {
            c.save()
            if (side == 1) c.scale(-1f, 1f, 500f, 0f)

            c.drawCircle(
                204f, 368f, 160f,
                fillP(Color.argb((15 + 150 * lt).toInt().coerceIn(0, 255), 255, 255, 255), lampGlowShader)
            )

            c.save()
            c.clipPath(lampPath)
            c.drawRect(120f, 290f, 290f, 336f, fillP(lerp(0xFF4A2A06.toInt(), 0xFFFF9A1A.toInt(), 0.3f)))
            c.drawRect(120f, 336f, 290f, 404f, fillP(lerp(0xFF4A0910.toInt(), 0xFFFF2B2B.toInt(), 0.25f + 0.75f * lt)))
            c.drawRect(120f, 404f, 290f, 450f, fillP(0xFFBFC3CA.toInt()))
            val tp = strokeP(0x22000000, 1.5f)
            var x = 140f
            while (x < 276f) {
                c.drawLine(x, 290f, x, 450f, tp)
                x += 9f
            }
            c.restore()
            c.drawPath(lampPath, strokeP(0xFF050506.toInt(), 5f))
            c.restore()
        }
    }

    private fun drawBumper(c: Canvas) {
        rect.set(100f, 540f, 900f, 654f)
        c.drawRoundRect(rect, 36f, 36f, fillP(Color.WHITE, bodyShader))
        c.drawRoundRect(rect, 36f, 36f, fillP(Color.WHITE, bumperSheen))
        c.drawRoundRect(rect, 36f, 36f, strokeP(edgeColor, 3f))

        // нижний чёрный пластик
        rect.set(112f, 614f, 888f, 650f)
        c.drawRoundRect(rect, 18f, 18f, fillP(0xFF131417.toInt()))

        // катафоты
        rect.set(128f, 584f, 178f, 602f)
        c.drawRoundRect(rect, 5f, 5f, fillP(0xFFB3121B.toInt()))
        rect.set(822f, 584f, 872f, 602f)
        c.drawRoundRect(rect, 5f, 5f, fillP(0xFFB3121B.toInt()))

        // номерной знак
        rect.set(386f, 552f, 614f, 622f)
        c.drawRoundRect(rect, 10f, 10f, fillP(0xFF0A0A0C.toInt()))
        rect.set(396f, 560f, 604f, 614f)
        c.drawRoundRect(rect, 7f, 7f, fillP(0xFFF4F4EF.toInt()))
        c.drawRoundRect(rect, 7f, 7f, strokeP(0xFF111111.toInt(), 3f))
        c.drawLine(548f, 563f, 548f, 611f, strokeP(0xFF111111.toInt(), 2.5f))
        textP.textSize = 34f
        c.drawText("А110ВС", 472f, 598f, textP)
        textP.textSize = 26f
        c.drawText("47", 576f, 587f, textP)
        textP.textSize = 11f
        c.drawText("RUS", 576f, 605f, textP)

        // выхлоп
        rect.set(276f, 640f, 336f, 664f)
        c.drawOval(rect, fillP(Color.WHITE, chromeShader))
        rect.set(284f, 645f, 328f, 660f)
        c.drawOval(rect, fillP(0xFF020203.toInt()))
    }
}
