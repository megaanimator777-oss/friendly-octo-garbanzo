package com.vazbass.app

import android.content.Context
import android.content.SharedPreferences

object Prefs {
    const val FILE = "vazbass"
    const val CAR_BLACK = "car_black"
    const val ACCENT = "accent"
    const val SENS = "sens"
    const val BARS = "bars"
    const val SUB_ON = "sub_on"
    const val POWER = "power"
    const val MUFFLE = "muffle"
    const val METHOD = "method"

    fun get(c: Context): SharedPreferences = c.getSharedPreferences(FILE, Context.MODE_PRIVATE)
}
