package com.vazbass.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var prefs: SharedPreferences
    private lateinit var root: LinearLayout
    private lateinit var car: CarView
    private lateinit var panel: ScrollView
    private lateinit var startBtn: Button
    private lateinit var status: TextView
    private val handler = Handler(Looper.getMainLooper())
    private var panelVisible = true
    private var hintShown = false

    private val accents = intArrayOf(
        0xFF00B0FF.toInt(), 0xFFFF1744.toInt(), 0xFF00E676.toInt(),
        0xFFD500F9.toInt(), 0xFFFFEA00.toInt(), 0xFFFFFFFF.toInt()
    )

    private val ticker = object : Runnable {
        override fun run() {
            refreshStatus()
            handler.postDelayed(this, 600)
        }
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs.get(this)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK

        root = LinearLayout(this)
        root.setBackgroundColor(0xFF05060B.toInt())

        car = CarView(this)
        car.carBlack = prefs.getBoolean(Prefs.CAR_BLACK, true)
        car.accent = prefs.getInt(Prefs.ACCENT, accents[0])
        car.sensitivity = prefs.getInt(Prefs.SENS, 100) / 100f
        car.showBars = prefs.getBoolean(Prefs.BARS, true)
        car.setOnClickListener { togglePanel() }

        panel = ScrollView(this)
        panel.setBackgroundColor(0xFF0B0D14.toInt())
        panel.addView(buildPanel())

        root.addView(car)
        root.addView(panel)
        applyOrientation()
        setContentView(root)
    }

    private fun applyOrientation() {
        val land = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
        if (land) {
            root.orientation = LinearLayout.HORIZONTAL
            car.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1.5f)
            panel.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f)
        } else {
            root.orientation = LinearLayout.VERTICAL
            car.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
            panel.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1.15f)
        }
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        applyOrientation()
    }

    // ---------- Панель настроек ----------

    private fun buildPanel(): View {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(16), dp(12), dp(16), dp(28))

        status = TextView(this)
        status.setTextColor(0xFFB0B6C3.toInt())
        status.textSize = 13f
        col.addView(status)

        startBtn = Button(this)
        startBtn.textSize = 16f
        startBtn.setOnClickListener { onStartClicked() }
        col.addView(startBtn, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ))

        col.addView(header("Машина"))
        col.addView(radios(listOf("Чёрная", "Белая"), if (prefs.getBoolean(Prefs.CAR_BLACK, true)) 0 else 1, true) { i ->
            prefs.edit().putBoolean(Prefs.CAR_BLACK, i == 0).apply()
            car.carBlack = (i == 0)
        })

        col.addView(header("Цвет подсветки"))
        col.addView(swatches())

        col.addView(header("Визуализация"))
        col.addView(seek("Чувствительность", Prefs.SENS, 250, 100) { v ->
            car.sensitivity = v / 100f
        })
        col.addView(toggle("Эквалайзер на фоне", Prefs.BARS, true) { v -> car.showBars = v })

        col.addView(header("Звук: саб в багажнике"))
        col.addView(toggle("Включить обработку звука", Prefs.SUB_ON, false) { v ->
            if (v && !AudioBus.running) {
                Toast.makeText(this, "Эффект заработает после нажатия «Старт»", Toast.LENGTH_LONG).show()
            }
        })
        col.addView(seek("Мощность баса", Prefs.POWER, 100, 80) { })
        col.addView(seek("Глухота (как из багажника)", Prefs.MUFFLE, 100, 60) { })
        col.addView(note("Эффект меняет звук всех плееров сразу и работает, пока приложение запущено. " +
            "Лучше всего звучит в наушниках или на колонке: динамик телефона глубокий бас воспроизвести не может. " +
            "Не ставь большую громкость вместе с максимумом баса."))

        col.addView(header("Как слушать звук"))
        col.addView(radios(
            listOf("Системный микшер (по умолчанию)", "Запись воспроизведения (Android 10+)"),
            prefs.getInt(Prefs.METHOD, 0), false
        ) { i ->
            prefs.edit().putInt(Prefs.METHOD, i).apply()
            if (AudioBus.running) {
                stopService(Intent(this, AudioService::class.java))
                handler.postDelayed({ beginCapture() }, 500)
            }
        })
        col.addView(note("Если музыка играет, а машина стоит на месте — переключи на второй способ."))
        col.addView(note("Нажми на машину, чтобы скрыть или показать настройки."))
        return col
    }

    private fun header(text: String): TextView {
        val t = TextView(this)
        t.text = text.uppercase()
        t.setTextColor(0xFF7FD6FF.toInt())
        t.textSize = 12f
        t.typeface = Typeface.DEFAULT_BOLD
        t.setPadding(0, dp(18), 0, dp(6))
        return t
    }

    private fun note(text: String): TextView {
        val t = TextView(this)
        t.text = text
        t.setTextColor(0xFF8A90A0.toInt())
        t.textSize = 12f
        t.setPadding(0, dp(6), 0, dp(2))
        return t
    }

    private fun seek(title: String, key: String, max: Int, def: Int, onChange: (Int) -> Unit): View {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        val label = TextView(this)
        label.setTextColor(Color.WHITE)
        label.textSize = 14f
        val bar = SeekBar(this)
        bar.max = max
        bar.progress = prefs.getInt(key, def)
        label.text = "$title: ${bar.progress}"
        bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
                label.text = "$title: $p"
                if (fromUser) {
                    prefs.edit().putInt(key, p).apply()
                    onChange(p)
                }
            }
            override fun onStartTrackingTouch(s: SeekBar) {}
            override fun onStopTrackingTouch(s: SeekBar) {}
        })
        box.addView(label)
        box.addView(bar)
        return box
    }

    private fun toggle(title: String, key: String, def: Boolean, onChange: (Boolean) -> Unit): Switch {
        val sw = Switch(this)
        sw.text = title
        sw.setTextColor(Color.WHITE)
        sw.textSize = 14f
        sw.setPadding(0, dp(8), 0, dp(8))
        sw.isChecked = prefs.getBoolean(key, def)
        sw.setOnCheckedChangeListener { _, v ->
            prefs.edit().putBoolean(key, v).apply()
            onChange(v)
        }
        return sw
    }

    private fun radios(options: List<String>, selected: Int, horizontal: Boolean, onSelect: (Int) -> Unit): RadioGroup {
        val g = RadioGroup(this)
        g.orientation = if (horizontal) LinearLayout.HORIZONTAL else LinearLayout.VERTICAL
        options.forEachIndexed { i, t ->
            val rb = RadioButton(this)
            rb.id = View.generateViewId()
            rb.text = t
            rb.setTextColor(Color.WHITE)
            rb.textSize = 14f
            g.addView(rb)
            if (i == selected) rb.isChecked = true
        }
        g.setOnCheckedChangeListener { grp, checkedId ->
            onSelect(grp.indexOfChild(grp.findViewById(checkedId)))
        }
        return g
    }

    private fun swatches(): View {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        val items = ArrayList<Pair<View, Int>>()
        fun refresh() {
            val cur = prefs.getInt(Prefs.ACCENT, accents[0])
            for ((v, c) in items) {
                val d = GradientDrawable()
                d.shape = GradientDrawable.OVAL
                d.setColor(c)
                d.setStroke(dp(3), if (c == cur) Color.WHITE else 0x33FFFFFF)
                v.background = d
            }
        }
        for (c in accents) {
            val v = View(this)
            val lp = LinearLayout.LayoutParams(dp(38), dp(38))
            lp.rightMargin = dp(12)
            v.layoutParams = lp
            v.setOnClickListener {
                prefs.edit().putInt(Prefs.ACCENT, c).apply()
                car.accent = c
                refresh()
            }
            items.add(Pair(v, c))
            row.addView(v)
        }
        refresh()
        return row
    }

    private fun togglePanel() {
        panelVisible = !panelVisible
        panel.visibility = if (panelVisible) View.VISIBLE else View.GONE
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = if (panelVisible) {
            View.SYSTEM_UI_FLAG_VISIBLE
        } else {
            View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        }
        if (!panelVisible && !hintShown) {
            hintShown = true
            Toast.makeText(this, "Нажми на машину, чтобы вернуть настройки", Toast.LENGTH_SHORT).show()
        }
    }

    // ---------- Запуск и разрешения ----------

    private fun onStartClicked() {
        if (AudioBus.running) {
            stopService(Intent(this, AudioService::class.java))
            return
        }
        val need = ArrayList<String>()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            need.add(Manifest.permission.RECORD_AUDIO)
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            need.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        if (need.isNotEmpty()) {
            requestPermissions(need.toTypedArray(), 1)
            return
        }
        beginCapture()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            beginCapture()
        } else {
            Toast.makeText(this, "Без доступа к звуку визуализация не работает", Toast.LENGTH_LONG).show()
        }
    }

    private fun beginCapture() {
        val method = prefs.getInt(Prefs.METHOD, 0)
        if (method == 1 && Build.VERSION.SDK_INT >= 29) {
            val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            @Suppress("DEPRECATION")
            startActivityForResult(mpm.createScreenCaptureIntent(), 2)
        } else {
            startAudioService(0, null)
        }
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 2) {
            if (resultCode == RESULT_OK && data != null) {
                startAudioService(resultCode, data)
            } else {
                Toast.makeText(this, "Нужно разрешить запись звука", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun startAudioService(code: Int, data: Intent?) {
        val i = Intent(this, AudioService::class.java)
        i.putExtra("mode", if (data != null) 1 else 0)
        if (data != null) {
            i.putExtra("code", code)
            i.putExtra("data", data)
        }
        startForegroundService(i)
    }

    // ---------- Статус ----------

    private fun refreshStatus() {
        val running = AudioBus.running
        startBtn.text = if (running) "■  СТОП" else "▶  СТАРТ"
        val am = getSystemService(AUDIO_SERVICE) as AudioManager
        val err = AudioBus.error
        status.text = when {
            !running -> "Демо: машина качает сама. Нажми «Старт», чтобы она заиграла под твою музыку."
            err != null -> err
            am.isMusicActive && System.currentTimeMillis() - AudioBus.lastSignal > 4000 ->
                "Музыка играет, но звук не приходит. Включи второй способ ниже."
            !am.isMusicActive -> "Слушаю. Запусти музыку в любом плеере."
            else -> "Работает ✓"
        }
    }

    override fun onResume() {
        super.onResume()
        handler.post(ticker)
    }

    override fun onPause() {
        handler.removeCallbacks(ticker)
        super.onPause()
    }
}
